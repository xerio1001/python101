class InvalidMapSize(Exception):
    pass


class TypeError(Exception):
    pass


class InsufficientAmountOfHealth(Exception):
    pass
