import discord
from discord.ext import commands


client = commands.Bot(command_prefix="Æ")


@client.command(name = "version")
async def version(context):

    # create embed message
    myEmbed = discord.Embed(title = "Current version.", description = "The bot is in version 1.0.", color = 0xff0000)
    myEmbed.add_field(name = "Version code:", value = "Python 3.10.2", inline = False)
    myEmbed.add_field(name = "Date released:", value = "February 19th, 2022", inline = False)
    myEmbed.set_footer(text = "This is a sample footer.")
    myEmbed.set_author(name = "Dario V.H.")

    # send embed message in the channel where the comand is given.
    await context.message.channel.send(embed = myEmbed)


@client.command(name = "DaChizzle")
async def version(context):

    # create embed message
    myEmbed = discord.Embed(title = "Chizzle", description = "Dick", color = 0x00ff00)
    myEmbed.add_field(name = "Chizzle", value = "Penis", inline = False)
    # send embed message in the channel where the comand is given.
    await context.message.channel.send(embed = myEmbed)


@client.event
async def on_ready():
    general_channel = client.get_channel(654069693216194576)
    await general_channel.send("I am back online!")


@client.event
async def on_disconnect():
    general_channel = client.get_channel(654069693216194576)
    await general_channel.send("I've been disconnected. Hope to see you soon!")


client.run('OTQ0MzAxMDc2OTA2MTIzMzk1.Yg_m6Q.MqKbrzM4sQ2Bn60oeEeMIWD3gcA')
