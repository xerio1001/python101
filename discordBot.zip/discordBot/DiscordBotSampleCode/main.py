import discord
from discord.ext import commands
import DiscordBotSampleCode.music as music

cogs = [music]

client = commands.Bot(command_prefix="?", intents = discord.Intents.all())

for i in range(len(cogs)):
    cogs[i].setup(client)

client = commands.Bot(command_prefix="?", intents = discord.Intents.all())

client.run("OTQ0MzAxMDc2OTA2MTIzMzk1.Yg_m6Q.MqKbrzM4sQ2Bn60oeEeMIWD3gcA")