<html>
<link href="style.css" rel="stylesheet" type="text/css">
<title>Log in</title>
<body>

   <div id="main">

      <div class="paddingTop"><!--- placefiller top---></div>

        <h4 class="title">You are succesfully logged in!</h4>
        Not really tho :)

   </div>

</body>
</html>