<!DOCTYPE html>
<html>
<head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <title>Login screen</title>
</head>
<body>

    <div id="main">
        
        <div id="header"><a href="login.php"><img src="images/discord_server_final_bew.jpg" width="200px" height="200px"></a></div>

        <div id="placeholder">

            <h4>Login</h4>

            <form method="POST" action="logged_in.php">
                
                <input type="text" placeholder="Username*" name="usern" required><br>
                <input type="password" placeholder="Password*" name="pw" required><br>
                <input type="submit" value="Log in" name="submit">

            </form>

                <div id="home"><a href="index.php"><span class="register">home</span></a></div>
                <div id="register"><a href="register.php"><span class="register">Register</span></a></div>

        </div>

        <div id="footer">Welcome to the lunar discord website!</div>

    </div>

</body>
</html>