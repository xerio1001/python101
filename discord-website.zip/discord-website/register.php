<!DOCTYPE html>
<link href="style.css" rel="stylesheet" type="text/css">
<title>Register</title>
<body>

    <div id="main">

        <div class="placeholder_register">

            <form method="POST" action="registerCompletion.php">
                
                <h4>Register</h4>

                <input type="text" placeholder="Name*" name="name" required><br>
                <input type="text" placeholder="Username*" name="usern" required><br>
                <input type="email" placeholder="Email address*" name="email" required><br>
                <input type="password" placeholder="Password*" name="pw" required><br>
                <input type="password" placeholder="Confirm password*" name="cpw" required><br>

                <input type="submit" value="register" name="submit">

            </form>

            <a href="login.php">Log in</a>

        </div>

        <div id="footer">We are happy to see you register!</div>


    </div>

</body>
</html>