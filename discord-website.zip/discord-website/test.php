<html>
<head>
    <title>Page</title>
</head>
<body>

<?php

    $txt = "hello world";
    print $txt;

?>

<body>
</html>