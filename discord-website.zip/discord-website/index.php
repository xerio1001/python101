<?php
    include 'connectDB.php';
?>



<html>
<head>
    <link href="styleHomePage.css" rel="stylesheet" type="text/css">
    <title>Home</title>
</head>
<body>
    
    <div id="main">

        <div class="header"><h1>Welcome to our discord website!</h1></div>

        <div class="menu">
            <li><a href="login.php">Log-in</a></li> 
            <li><a href="register.php">Register</a></li>
        </div>

    </div>

</body>
</html>