<html>
<head>
    <link href="styleHomePage.css" rel="stylesheet" type="text/css">
    <title>Lunar homepage</title>
</head>
<body>
    
    <div id="main">



        <div class="header"><h1>Welcome to our discord website!</h1></div>



        <div class="menu">
            <a href="login.php">Log-in</a>
            <a href="register.php">Register</a>
        </div>

        <div id="info">
            <!--- raw txt --->
            <h1>Lunar</h1>
            <h4>
            We are a beginning server <br>
            wich would like to grow it's amount of members.<br>
            We'd like you to join us to achieve this goal!<p>
            will you come and join us?<br>
            Be one of us, make friends<br>
            and have fun!
            </h4>
            <!--- end raw txt --->
        </div>

        <div id="contact">
            <h2>Founder</h2>
            <ul>
                <li>Xerio1001</li>
            <h2>Mods</h2>
                <li>DaChizzle</li>
            </ul>
        </div>



        <div id="content">
            <img src="images/discord1MainPageEdit.jpg"><p>
            <hr>
            <p>
            <img src="images/discord5WelcomePageEdit.jpg">
            <hr>
            <p>
            <img src="images/discord3AnnouncmentsPageEdit.jpg">
            <hr>
            <p>
            <img src="images/discord2gamingPageEdit.jpg">
            <hr>
            <p>
            <img src="images/discord4CodingPageEdit.jpg">
            
        </div>



    </div>

</body>
</html>