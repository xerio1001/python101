<html>
<head>
    <link href="styleHomePage.css" rel="stylesheet" type="text/css">
    <title>Lunar homepage</title>
</head>
<body>
    
    <div id="main">



        <div class="header"><h1>Welcome to our discord website!</h1></div>



        <div class="menu">
            <a href="login.php">Log-in</a>
            <a href="register.php">Register</a>
        </div>



        <div id="contact">
            <h2>Mods</h2>
            <ul>
                <li>xerio1001: </li>
                <li>DaChizzle: </li>
            </ul>
        </div>



        <div id="content">
            <img src="images/discord1MainPage.jpg"><p>
            <img src="images/discord2gamingPage.jpg"><p>
            <img src="images/discord3AnnouncmentsPage.jpg">
        </div>



    </div>

</body>
</html>